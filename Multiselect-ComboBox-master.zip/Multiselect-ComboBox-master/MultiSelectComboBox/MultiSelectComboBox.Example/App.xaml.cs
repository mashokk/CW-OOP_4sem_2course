﻿using System.Windows;

namespace Sdl.MultiSelectComboBox.Example
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
	{
	}
}
